import java.util.Scanner;
import java.util.Random;

class MyProgram {
    public static void main(String[] args) {
        //Scanner object for user input
        Scanner sc = new Scanner(System.in);
        //Random object for computer choice
        Random random = new Random();
       
        System.out.println("Welcome To Rock, Paper, Scissors!");
        System.out.println("Choose a GameMode To Play:");
        //Show player choices
        System.out.println("1 - Best Of 3");
        System.out.println("2 - Best Of 5");
        System.out.println("3 - Best Of 7");
        System.out.println("4 - Unlimited Play (Type 'QUIT' to quit playing)");
       
        int totalWins = 0;
        int playerWins = 0;
        int computerWins = 0;
        //Indicates whether player wants to play unlimited games
        boolean unlimitedPlay = false;
        
        //Lines 1-23 were written by Sudhanv Beeravolu
       
        while (true) {
            System.out.println("Enter a number of your choice:");
            int mode = sc.nextInt();
           //Alerts user to put avaliable game modes
            if (mode < 1 || mode > 4) {
                System.out.println("Invalid Option. Choose one of the valid options");
                continue;
            }
           //Sets certain amount of wins per game mode
            if (mode == 1) {
                totalWins = 2;
            } else if (mode == 2) {
                totalWins = 3;
            } else if (mode == 3) {
                totalWins = 4;
            } else {
                unlimitedPlay = true;
            }
            
            int[] scores = new int[2]; // Array to hold player and computer wins
            
           //Lines 27-44 were written by Abaan Siddiqui
            while ((playerWins < totalWins && computerWins < totalWins) || unlimitedPlay) {
                System.out.println("Enter R to choose Rock, P to choose Paper, S to choose Scissors:");
                String playerChoice = sc.next();
               //Checks to see if player wants to quit playing
                if (playerChoice.equals("QUIT")) {
                    break;
                }
               //Alerts user to select valid playing choice
                if (!playerChoice.equals("R") && !playerChoice.equals("P") && !playerChoice.equals("S")) {
                    System.out.println("Invalid Choice. Please Enter R, P, or S:");
                    continue;
                   
                }
               //Generates Computer Choice
                String computerChoice = generateComputerChoice(random);
                System.out.println(" You chose " + playerChoice + ", Computer Chose " + computerChoice + ".");
               //Helps find winner of round
                String result = decideWinner(playerChoice, computerChoice, scores);
               //Output based off playerWin or UserWin
                if (result.equals("You Win This Round!")) {
                    playerWins++;
                } else if (result.equals("Computer Won This Round!")) {
                    computerWins++;
                }
                 //Lines 46-70 were written by Azaan Raza
               //Display score of round
                System.out.println(" You Have Won " + playerWins + " Games and Computer Has Won: " + computerWins + " Games");
            }
           //Helps find overall winner of the game
            if (!unlimitedPlay && playerWins == totalWins) {
                System.out.println("Congratulations! You Have Won");
            }
           
            if (!unlimitedPlay && computerWins == totalWins) {
                System.out.println("Sorry, You Have Lost This Round.");
            }
           //Checks to see if user wants to play again
            System.out.println("Type PA To Play Again or Another Key To Quit.");
            String playAgain = sc.next();
            if (!playAgain.equals("PA")) {
                break;
            }
           //Reset wincount if player wants to play again
            playerWins = 0;
            computerWins = 0;
        }
       //Close Scanner
        sc.close();
       //Lines 71-92 were written by Krish Vignesh
    }
   //Method to help generate the computer choice
    public static String generateComputerChoice(Random random) {
        int choice = random.nextInt(3);
       
        if (choice == 0) {
            return "R";
        } else if (choice == 1) {
            return "P";
        } else {
            return "S";
        }
        //Lines 96-107 were written by Abaan Siddiqui
    }
   //Method to find the winner of the game
  public static String decideWinner(String playerChoice, String computerChoice, int[] scores) {
    if (playerChoice.equals(computerChoice)) {
        return "It's a Tie!";
    } else if ((playerChoice.equals("R") && computerChoice.equals("S")) || 
               (playerChoice.equals("P") && computerChoice.equals("R")) || 
               (playerChoice.equals("S") && computerChoice.equals("P"))) {
        scores[0]++; // Increment player's win count
        return "You Win This Round!";
    } else {
        scores[1]++; // Increment computer's win count
        return "Computer Won This Round!";
    }
}
 //Lines 111-126 were written by Azaan Raza

}